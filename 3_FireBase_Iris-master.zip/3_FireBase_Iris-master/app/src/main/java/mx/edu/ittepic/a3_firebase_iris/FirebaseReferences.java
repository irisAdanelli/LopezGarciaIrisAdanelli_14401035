package mx.edu.ittepic.a3_firebase_iris;

/**
 * Created by OEM on 18/04/2018.
 */

public class FirebaseReferences {
    final public static String TUTORIAL_REFERENCE="tutorial";
    final public static String ALUMNO_REFERENCE="alumnos";
}

package mx.edu.ittepic.a3_1_consumo_de_servicios_web_iris;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}
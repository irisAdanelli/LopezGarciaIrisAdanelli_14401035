package mx.edu.ittepic.a3_2_consumo_de_servicios_web;

public interface AsyncResponse {
    void procesarRespuesta(String r);
}
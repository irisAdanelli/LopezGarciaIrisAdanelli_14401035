package mx.edu.ittepic.caso2_gestor_pacientes_irisadanellilopezgarcia;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by OEM on 15/03/2018.
 */

public class Buildings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buildings);


    }
}
